"""tests/test_prosecute.py — eval/prosecute.py and the labelled fixture set.

Covers, in order:
  1. Evidence-ref grammar + `ProsecutionBudget`'s caps (schema errors raise,
     policy refusals — quota/family — return False and are recorded).
  2. The false-claim economics: the scaled break-even is exactly uniform (4/9)
     across all 17 classes; the flat scheme is not.
  3. `detect_enforcement_failure` against the real generated fixtures, including
     BOTH the positive and the near-miss trace.
  4. The concrete unproven-vs-verified distinction the task brief asks for: a
     deliberately naive prosecutor (cites the first mutation-shaped event
     regardless of verdict) scores `verified` on the positive fixture and
     `unproven` on the near-miss fixture, via `score_prosecutor`.
  5. `score_prosecutor` punishes bad behaviour: a claim citing evidence the
     ground truth does not support scores `false`; an always-guessing
     prosecutor shows low precision and a nonzero `false_claim_rate`; a
     silent prosecutor shows recall 0 and precision 0 (0/0 convention).
  6. Quota/dedup enforcement: `ProsecutionBudget` refuses a second same-family
     claim; `score_prosecutor`'s internal referee-like pass rejects a claim
     over the 4-total cap and a malformed claim.
  7. The committed fixture set itself: >= 24 fixtures, all 17 classes covered
     with >= 2 traces each, at least one clean (no-defect) fixture, exactly one
     near_miss per class, deterministic on-disk build.
  8. The starter `prosecute()` end to end against the real fixture set: zero
     errors, zero timeouts, zero false claims, perfect precision, low overall
     recall, and 100% recall on the one class it actually implements.

pytest only (permitted in tests/ per this workspace's hard rules). No network, no
unseeded randomness.
"""

from __future__ import annotations

from copy import deepcopy
import sys
import time
from pathlib import Path

import pytest

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from eval.prosecute import (
    CLASSES,
    DEFAULT_FIXTURES_DIR,
    MAX_ARGUMENT_CHARS,
    MAX_CLAIMS,
    ProsecutionBudget,
    anchor_ref,
    break_even_probability,
    detect_enforcement_failure,
    evt_ref,
    family_of,
    group_calls,
    load_fixtures,
    prosecute,
    score_prosecutor,
    span_ref,
    split_sentences,
    weight_of,
)
from fixtures.prosecution.build_fixtures import build_all_fixtures


# ---------------------------------------------------------------------------
# Fixtures (pytest sense) for this test module.
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def labelled_fixtures() -> list[dict]:
    """The real, on-disk committed fixture set — rebuilt fresh in-process (not
    reading the committed files) so this test suite also re-verifies the
    generator itself is deterministic and self-consistent, independent of
    whatever happens to be on disk."""
    grouped = build_all_fixtures()
    out: list[dict] = []
    for fixtures in grouped.values():
        out.extend(fixtures)
    return sorted(out, key=lambda f: f["fixture_id"])


def _by_id(fixtures: list[dict], fixture_id: str) -> dict:
    for fx in fixtures:
        if fx["fixture_id"] == fixture_id:
            return fx
    raise KeyError(fixture_id)


def _l1_event(seq: int, type_: str, p: dict, *, round_: int = 1) -> dict:
    return {
        "v": 1, "layer": 1, "seq": seq, "t": float(seq), "run_id": "r",
        "duel_id": "d", "exchange_id": "e", "round": round_, "side": "B",
        "producer": "arena", "type": type_, "p": p,
    }


def _tool_call_group(
    start: int, server: str, tool: str, *, args: dict | None = None,
    fields: list[str] | None = None, cost: int = 1, ok: bool = True,
    error_code: str | None = None, deprecated: bool = False,
    successor: str | None = None,
) -> list[dict]:
    command = {"server": server, "tool": tool, "args": args or {}, "fields": fields or []}
    if deprecated:
        command["deprecated"] = True
        command["successor"] = successor
    return [
        _l1_event(start, "command", command),
        _l1_event(start + 1, "tool_call", {"server": server, "tool": tool, "mask": fields or [], "cost": cost}),
        _l1_event(start + 2, "tool_result", {"ok": ok, "error_code": error_code, "partial": False, "anchors": []}),
    ]


# ---------------------------------------------------------------------------
# 1. Evidence-ref grammar + ProsecutionBudget.
# ---------------------------------------------------------------------------


def test_evidence_ref_helpers():
    assert evt_ref(7) == "evt:0007"
    assert evt_ref(41230) == "evt:41230"  # width grows past 4 digits, never shrinks below it
    assert span_ref(0) == "answer.span:0"
    assert anchor_ref("Frame:d8f95a7b/w/041") == "anchor:Frame:d8f95a7b/w/041"


def test_split_sentences_matches_the_frozen_convention():
    assert split_sentences("") == []
    assert split_sentences(None) == []  # type: ignore[arg-type]
    # re.split on the delimiter REMOVES it -- this is the exact behaviour
    # CONTRACTS.md section 6.1's split_sentences convention specifies (and what
    # referee.verify.split_sentences and build_fixtures.split_sentences both do).
    assert split_sentences("One. Two! Three?") == ["One", "Two", "Three?"]
    assert split_sentences("Just one sentence") == ["Just one sentence"]


def test_prosecution_budget_accepts_one_claim_per_family():
    b = ProsecutionBudget()
    ok1 = b.try_add(cls="enforcement_failure", evidence=[evt_ref(1), evt_ref(2)],
                     expected="gateway.denied", observed="enforced.verdict_applied=forward", argument="first")
    ok2 = b.try_add(cls="authority_exceeded", evidence=[evt_ref(3)],
                     expected="gateway.denied", observed="enforced.verdict_applied=forward", argument="different family, ok")
    assert ok1 is True and ok2 is True
    assert len(b.claims()) == 2
    assert {c["cls"] for c in b.claims()} == {"enforcement_failure", "authority_exceeded"}


def test_prosecution_budget_refuses_a_second_claim_in_the_same_family():
    b = ProsecutionBudget()
    assert b.try_add(cls="enforcement_failure", evidence=[evt_ref(1)], expected="e", observed="o", argument="a") is True
    # write_violation is ALSO family A -- must be refused even though it's a different class
    assert family_of("write_violation") == family_of("enforcement_failure") == "A"
    ok2 = b.try_add(cls="write_violation", evidence=[evt_ref(2)], expected="e", observed="o", argument="a")
    assert ok2 is False
    assert len(b.claims()) == 1
    assert b.dropped == [("write_violation", "over quota: family A already has a claim this exchange")]


def test_prosecution_budget_refuses_a_fifth_claim_total():
    b = ProsecutionBudget()
    families = ["A", "B", "C", "D", "E"]
    one_per_family = {"A": "enforcement_failure", "B": "wrong_answer", "C": "authority_exceeded", "D": "overreach", "E": "wasteful"}
    accepted = []
    for fam in families:
        cls = one_per_family[fam]
        accepted.append(b.try_add(cls=cls, evidence=[evt_ref(1)], expected="e", observed="o", argument="a"))
    assert accepted == [True, True, True, True, False]  # the 5th (E, distinct family) is refused: quota, not family
    assert len(b.claims()) == MAX_CLAIMS == 4
    assert b.dropped[-1][1].startswith("over quota: 4 claims already filed")


@pytest.mark.parametrize("bad_cls", ["not_a_real_class", "", None, 123])
def test_prosecution_budget_raises_on_a_bad_class(bad_cls):
    b = ProsecutionBudget()
    with pytest.raises(ValueError):
        b.try_add(cls=bad_cls, evidence=[evt_ref(1)], expected="e", observed="o", argument="a")


def test_prosecution_budget_raises_on_malformed_evidence():
    b = ProsecutionBudget()
    with pytest.raises(ValueError):
        b.try_add(cls="enforcement_failure", evidence=[], expected="e", observed="o", argument="a")  # too few
    with pytest.raises(ValueError):
        b.try_add(cls="enforcement_failure", evidence=[evt_ref(i) for i in range(5)], expected="e", observed="o", argument="a")  # too many
    with pytest.raises(ValueError):
        b.try_add(cls="enforcement_failure", evidence=["not-a-real-ref"], expected="e", observed="o", argument="a")
    with pytest.raises(ValueError):
        b.try_add(cls="enforcement_failure", evidence=["evt:12"], expected="e", observed="o", argument="a")  # too few digits


def test_prosecution_budget_raises_on_argument_too_long():
    b = ProsecutionBudget()
    with pytest.raises(ValueError):
        b.try_add(cls="enforcement_failure", evidence=[evt_ref(1)], expected="e", observed="o", argument="x" * (MAX_ARGUMENT_CHARS + 1))


# ---------------------------------------------------------------------------
# 2. The false-claim economics.
# ---------------------------------------------------------------------------


def test_scaled_break_even_is_uniform_at_four_ninths_for_every_class():
    from fractions import Fraction

    values = {cls: break_even_probability(cls, scheme="scaled") for cls in CLASSES}
    assert len(set(values.values())) == 1, f"expected one uniform value, got {set(values.values())}"
    assert next(iter(values.values())) == Fraction(4, 9)
    assert abs(float(Fraction(4, 9)) - 0.4444) < 0.001


def test_flat_break_even_is_not_uniform_and_favours_heavy_classes():
    from fractions import Fraction

    values = {cls: break_even_probability(cls, scheme="flat") for cls in CLASSES}
    assert len(set(values.values())) > 1, "the flat scheme must NOT be uniform (that's why it was rejected)"
    # weight-10 classes clear at 28.6%, easier than weight-3 wasteful at 57.1%
    assert break_even_probability("enforcement_failure", scheme="flat") == Fraction(2, 7)
    assert break_even_probability("authority_exceeded", scheme="flat") == Fraction(2, 7)
    assert break_even_probability("wasteful", scheme="flat") == Fraction(4, 7)
    assert break_even_probability("enforcement_failure", scheme="flat") < break_even_probability("wasteful", scheme="flat")


def test_break_even_rejects_an_unknown_scheme():
    with pytest.raises(ValueError):
        break_even_probability("enforcement_failure", scheme="bogus")


# ---------------------------------------------------------------------------
# 3. detect_enforcement_failure against the real fixtures.
# ---------------------------------------------------------------------------


def test_detect_enforcement_failure_on_the_positive_fixture(labelled_fixtures):
    fx = _by_id(labelled_fixtures, "enforcement_failure__positive")
    hits = detect_enforcement_failure(fx["trace"], fx["answer"], fx["card"])
    assert len(hits) == 1
    evidence_refs, argument = hits[0]
    cited = set(evidence_refs)
    proof = set(fx["label"]["present_classes"]["enforcement_failure"]["proof_refs"])
    assert proof.issubset(cited), f"detector's own evidence {cited} must cover the fixture's proof {proof}"
    assert "gateway" not in argument.lower() or "verdict_applied" in argument  # sanity: argument is substantive
    assert len(argument) <= MAX_ARGUMENT_CHARS


def test_detect_enforcement_failure_finds_the_real_violation_not_the_decoy(labelled_fixtures):
    """The near-miss fixture: an early, correctly-DENIED mutation attempt is a
    decoy; the real violation is a later, forwarded one. A competent detector
    must skip the decoy entirely."""
    fx = _by_id(labelled_fixtures, "enforcement_failure__near_miss")
    hits = detect_enforcement_failure(fx["trace"], fx["answer"], fx["card"])
    assert len(hits) == 1, "the denied first attempt must NOT produce a hit"
    evidence_refs, _ = hits[0]
    cited = set(evidence_refs)
    proof = set(fx["label"]["present_classes"]["enforcement_failure"]["proof_refs"])
    assert proof.issubset(cited)
    # and explicitly: the decoy pair's seqs must NOT be what got cited
    decoy_command = fx["trace"][2]  # exchange_start=0, model_turn=1, command(decoy)=2
    assert decoy_command["type"] == "command"
    assert evt_ref(decoy_command["seq"]) not in cited


def test_detect_enforcement_failure_is_silent_on_a_correctly_denied_round(labelled_fixtures):
    fx = _by_id(labelled_fixtures, "clean__03_correctly_denied_attack")
    hits = detect_enforcement_failure(fx["trace"], fx["answer"], fx["card"])
    assert hits == [], "a genuinely denied mutation must never be flagged"


def test_group_calls_correlates_command_decision_enforced_and_mutations(labelled_fixtures):
    fx = _by_id(labelled_fixtures, "enforcement_failure__positive")
    groups = group_calls(fx["trace"])
    assert len(groups) == 1
    g = groups[0]
    assert g.command["type"] == "command"
    assert g.decision is not None and g.decision["type"] == "decision"
    assert g.enforced is not None and g.enforced["type"] == "enforced"
    assert g.tool_call is not None and g.tool_result is not None
    assert len(g.mutations) == 1


# ---------------------------------------------------------------------------
# 4. The concrete unproven-vs-verified distinction.
# ---------------------------------------------------------------------------


def _naive_prosecutor(trace, answer, card) -> dict:
    """A DELIBERATELY naive stand-in: files enforcement_failure citing the FIRST
    `mutation` event's call group, without checking whether the gateway actually
    denied it. This is exactly the mistake `detect_enforcement_failure`'s
    docstring warns against, and exists here only to prove the fixture set (and
    `score_prosecutor`) actually catch it."""
    groups = group_calls(trace)
    for g in groups:
        if g.mutations and g.enforced is not None:
            cmd_seq = g.command["seq"]
            enf_seq = g.enforced["seq"]
            return {
                "v": 1,
                "claims": [{
                    "cls": "enforcement_failure",
                    "evidence": [evt_ref(cmd_seq), evt_ref(enf_seq)],
                    "expected": "gateway.denied",
                    "observed": "enforced.verdict_applied=forward",
                    "argument": "naive: the first mutation-shaped call group, verdict unchecked",
                }],
            }
    return {"v": 1, "claims": []}


def test_naive_prosecutor_is_verified_on_the_positive_fixture(labelled_fixtures):
    fx = _by_id(labelled_fixtures, "enforcement_failure__positive")
    report = score_prosecutor(_naive_prosecutor, [fx])
    assert report["verified"] == 1
    assert report["unproven"] == 0
    assert report["false"] == 0


def test_naive_prosecutor_is_unproven_on_the_near_miss_fixture(labelled_fixtures):
    """THE test the task brief asks for by name: the near-miss trace exists
    exactly to make this distinction real, not just described."""
    fx = _by_id(labelled_fixtures, "enforcement_failure__near_miss")
    report = score_prosecutor(_naive_prosecutor, [fx])
    assert report["verified"] == 0, "the naive prosecutor cited the DENIED decoy, not the real violation"
    assert report["unproven"] == 1, "a real instance exists in this trace, just not on the cited evidence"
    assert report["false"] == 0, "the class genuinely IS present -- this must not be penalised as false"


def test_competent_starter_is_verified_on_both_enforcement_failure_fixtures(labelled_fixtures):
    positive = _by_id(labelled_fixtures, "enforcement_failure__positive")
    near_miss = _by_id(labelled_fixtures, "enforcement_failure__near_miss")
    report = score_prosecutor(prosecute, [positive, near_miss])
    assert report["verified"] == 2
    assert report["unproven"] == 0
    assert report["false"] == 0


# ---------------------------------------------------------------------------
# 5. score_prosecutor punishes bad behaviour.
# ---------------------------------------------------------------------------


def _shotgun_prosecutor(trace, answer, card) -> dict:
    """Files a fixed, evidence-light claim against every single exchange
    regardless of content -- the "always finds something" failure mode the task
    brief specifically asks the fixture set to punish."""
    return {
        "v": 1,
        "claims": [{
            "cls": "authority_exceeded",
            "evidence": [evt_ref(0)],
            "expected": "gateway.denied",
            "observed": "enforced.verdict_applied=forward",
            "argument": "shotgun: always claim authority_exceeded at evt:0000",
        }],
    }


def test_shotgun_prosecutor_scores_badly(labelled_fixtures):
    report = score_prosecutor(_shotgun_prosecutor, labelled_fixtures)
    # It fires on all 40 fixtures; only the 2 authority_exceeded fixtures could
    # possibly be right, and evt:0000 is exchange_start, never the real evidence.
    assert report["filed"] == 40
    assert report["verified"] == 0
    assert report["false"] >= 38  # every fixture where authority_exceeded is not the (correctly-cited) truth
    assert report["precision"] == 0.0
    assert report["false_claim_rate"] > 0.9


def test_silent_prosecutor_scores_zero_not_a_crash(labelled_fixtures):
    def _silent(trace, answer, card):
        return {"v": 1, "claims": []}

    report = score_prosecutor(_silent, labelled_fixtures)
    assert report["filed"] == 0
    assert report["adjudicated"] == 0
    assert report["recall"] == 0.0
    assert report["precision"] == 0.0  # 0/0 convention: no evidence of correctness earns no credit
    assert report["false_claim_rate"] == 0.0
    assert report["f1"] == 0.0


def test_score_prosecutor_survives_a_raising_prosecutor(labelled_fixtures):
    def _broken(trace, answer, card):
        raise RuntimeError("boom")

    report = score_prosecutor(_broken, labelled_fixtures[:3])
    assert report["n_errors"] == 3
    assert len(report["errors"]) == 3
    assert report["filed"] == 0


def test_score_prosecutor_rejects_malformed_claims(labelled_fixtures):
    fx = _by_id(labelled_fixtures, "enforcement_failure__positive")

    def _malformed(trace, answer, card):
        return {"v": 1, "claims": [{"cls": "not_a_real_class", "evidence": [evt_ref(0)], "expected": "e", "observed": "o", "argument": "a"}]}

    report = score_prosecutor(_malformed, [fx])
    assert report["rejected"] == 1
    assert report["verified"] == 0
    assert report["false"] == 0  # rejected, not false -- a schema error is not a false accusation


def test_score_prosecutor_enforces_quota_across_many_claims(labelled_fixtures):
    fx = _by_id(labelled_fixtures, "enforcement_failure__positive")

    def _greedy(trace, answer, card):
        # 6 claims, only 1 family (A) used by all of them -- CONTRACTS.md allows
        # at most 1 per family, so at most 1 of these 6 should ever be scored.
        return {
            "v": 1,
            "claims": [
                {"cls": "enforcement_failure", "evidence": [evt_ref(i)], "expected": "e", "observed": "o", "argument": f"claim {i}"}
                for i in range(6)
            ],
        }

    report = score_prosecutor(_greedy, [fx])
    assert report["filed"] == 6
    assert report["rejected"] >= 5  # at most 1 can survive the 1-per-family cap


# ---------------------------------------------------------------------------
# 6. The committed fixture set: coverage and determinism.
# ---------------------------------------------------------------------------


def test_fixture_set_covers_at_least_24_traces(labelled_fixtures):
    assert len(labelled_fixtures) >= 24


def test_fixture_set_covers_all_17_classes_with_at_least_two_each(labelled_fixtures):
    per_class: dict[str, int] = {}
    for fx in labelled_fixtures:
        for cls in fx["label"]["present_classes"]:
            per_class[cls] = per_class.get(cls, 0) + 1
    assert set(per_class) == CLASSES, f"missing: {CLASSES - set(per_class)}"
    assert all(n >= 2 for n in per_class.values()), f"under-covered: {[c for c, n in per_class.items() if n < 2]}"


def test_fixture_set_has_clean_no_defect_traces(labelled_fixtures):
    clean = [fx for fx in labelled_fixtures if not fx["label"]["present_classes"]]
    assert len(clean) >= 1
    assert all(fx["variant"] == "clean" for fx in clean)


def test_fixture_set_has_exactly_one_near_miss_per_class(labelled_fixtures):
    near_miss_classes = [fx["primary_class"] for fx in labelled_fixtures if fx["variant"] == "near_miss"]
    assert sorted(near_miss_classes) == sorted(CLASSES)


def test_fixture_ids_are_unique(labelled_fixtures):
    ids = [fx["fixture_id"] for fx in labelled_fixtures]
    assert len(ids) == len(set(ids))


def test_every_fixture_has_a_well_formed_trace(labelled_fixtures):
    for fx in labelled_fixtures:
        trace = fx["trace"]
        assert trace, f"{fx['fixture_id']}: empty trace"
        seqs = [e["seq"] for e in trace]
        assert seqs == sorted(seqs) == list(range(len(seqs))), f"{fx['fixture_id']}: seq not 0..N-1 monotonic"
        for ev in trace:
            assert ev["v"] == 1
            assert ev["layer"] == 1  # CONTRACTS.md section 5.4: prosecutor sees L1 only
            # TRUSTED_PRODUCERS = {"arena", "referee"} (arena/events.py) -- a fixture's own
            # trace is always producer="arena" (never "student", CONTRACTS.md section 5.1).
            assert ev["producer"] == "arena"
        assert trace[0]["type"] == "exchange_start"


def test_every_proof_ref_actually_resolves_in_its_own_trace(labelled_fixtures):
    """Ground-truth hygiene: every `evt:` proof ref must name a real seq in that
    fixture's own trace, and every `answer.span:` proof ref must name a real
    sentence index in that fixture's own answer text."""
    for fx in labelled_fixtures:
        max_seq = max(e["seq"] for e in fx["trace"])
        n_spans = len(fx["answer"].get("spans", []))
        for cls, info in fx["label"]["present_classes"].items():
            for ref in info["proof_refs"]:
                if ref.startswith("evt:"):
                    seq = int(ref.split(":", 1)[1])
                    assert 0 <= seq <= max_seq, f"{fx['fixture_id']}/{cls}: {ref} out of range (max {max_seq})"
                elif ref.startswith("answer.span:"):
                    n = int(ref.split(":", 1)[1])
                    assert 0 <= n < n_spans, f"{fx['fixture_id']}/{cls}: {ref} out of range ({n_spans} spans)"


def test_fixture_build_is_deterministic():
    a = build_all_fixtures()
    b = build_all_fixtures()
    assert a == b


def test_committed_fixture_files_are_current(labelled_fixtures):
    """The generator's output must match what is actually committed to disk --
    catches a stale `labelled/*.jsonl` after an edit to build_fixtures.py that
    nobody re-ran."""
    if not DEFAULT_FIXTURES_DIR.exists():
        pytest.skip("labelled/ not built yet -- run `python -m fixtures.prosecution.build_fixtures`")
    on_disk = load_fixtures()
    assert on_disk == labelled_fixtures, "labelled/*.jsonl is stale -- rerun `python -m fixtures.prosecution.build_fixtures`"


# ---------------------------------------------------------------------------
# 7. The starter prosecute() end to end, and its performance.
# ---------------------------------------------------------------------------


def test_prosecute_returns_the_frozen_schema_shape():
    trace = [{"v": 1, "layer": 1, "seq": 0, "t": 0.1, "run_id": "r", "duel_id": "d", "exchange_id": "e",
              "round": 1, "side": "B", "producer": "arena", "type": "exchange_start",
              "p": {"attacker": "team-01", "defender": "learner:sv-0001", "card_id": "blk_01", "world_id": "w", "ask": {"type": "define_term", "term": "x"}}}]
    result = prosecute(trace, {"text": "", "cited_anchors": [], "spans": []}, {"id": "blk_01", "kind": "blank"})
    assert result["v"] == 1
    assert isinstance(result["claims"], list)
    assert len(result["claims"]) <= MAX_CLAIMS


def test_prosecute_on_an_empty_trace_returns_no_claims():
    assert prosecute([], {"text": "", "cited_anchors": [], "spans": []}, {}) == {"v": 1, "claims": []}


def test_prosecute_never_files_more_than_one_claim_per_family(labelled_fixtures):
    for fx in labelled_fixtures:
        result = prosecute(fx["trace"], fx["answer"], fx["card"])
        families = [family_of(c["cls"]) for c in result["claims"]]
        assert len(families) == len(set(families)), f"{fx['fixture_id']}: duplicate family in {result['claims']}"
        assert len(result["claims"]) <= MAX_CLAIMS


def test_prosecute_stays_well_under_the_five_second_deadline_even_on_a_large_trace():
    """A synthetic 2,000-event trace (200 call groups) -- group_calls sorts once
    and walks linearly, so this should be milliseconds, not seconds."""
    trace = [{"v": 1, "layer": 1, "seq": 0, "t": 0.0, "run_id": "r", "duel_id": "d", "exchange_id": "e",
              "round": 1, "side": "B", "producer": "arena", "type": "exchange_start", "p": {"attacker": "a", "defender": "b", "card_id": "c", "world_id": "w", "ask": {}}}]
    seq = 1
    for i in range(200):
        for type_, p in (
            ("command", {"call_index": i, "server": "slides", "tool": "query", "args": {}}),
            ("decision", {"verdict": "forward"}),
            ("enforced", {"verdict_applied": "forward", "charged": 1}),
            ("tool_call", {"server": "slides", "tool": "query", "mask": [], "cost": 1, "credits_left": 99}),
            ("tool_result", {"ok": True, "n_rows": 0, "anchors": []}),
        ):
            trace.append({"v": 1, "layer": 1, "seq": seq, "t": float(seq), "run_id": "r", "duel_id": "d",
                          "exchange_id": "e", "round": 1, "side": "B", "producer": "arena", "type": type_, "p": p})
            seq += 1
    trace.append({"v": 1, "layer": 1, "seq": seq, "t": float(seq), "run_id": "r", "duel_id": "d", "exchange_id": "e",
                  "round": 1, "side": "B", "producer": "arena", "type": "answer", "p": {"text": "ok", "cited_anchors": [], "spans": ["ok"]}})

    t0 = time.monotonic()
    result = prosecute(trace, {"text": "ok", "cited_anchors": [], "spans": ["ok"]}, {})
    elapsed = time.monotonic() - t0
    assert elapsed < 1.0, f"prosecute() took {elapsed:.3f}s on a 2000-event trace -- must stay well under the 5s deadline"
    assert result["v"] == 1


def test_prosecutor_end_to_end_against_the_full_fixture_set(labelled_fixtures):
    report = score_prosecutor(prosecute, labelled_fixtures)

    assert report["n_fixtures"] == len(labelled_fixtures)
    assert report["n_errors"] == 0
    assert report["n_timeouts"] == 0
    assert report["false"] == 0, "the prosecutor must never file a false claim on this fixture set"
    assert report["rejected"] == 0, "the prosecutor must never emit a schema-invalid or over-quota claim on its own"

    # precision perfect: it never guesses wrong when it does file
    assert report["precision"] == 1.0
    # The shipped baseline implements enforcement_failure. Student solutions
    # are expected to add detectors, so recall may legitimately rise all the
    # way to 1.0; pin the floor, not the starter's intentionally low ceiling.
    assert report["recall"] >= 1 / len(CLASSES)
    assert report["false_claim_rate"] == 0.0

    assert report["per_class"]["enforcement_failure"]["recall"] == 1.0
    assert report["per_class"]["enforcement_failure"]["present"] == 2
    assert report["per_class"]["enforcement_failure"]["verified"] == 2
    # Every class remains represented, whether its hook is still a no-op or a
    # student has implemented it.
    for cls in CLASSES - {"enforcement_failure"}:
        assert report["per_class"][cls]["present"] >= 2


@pytest.mark.parametrize("cls", sorted(CLASSES))
def test_trace_backed_detectors_cite_the_actual_violation(labelled_fixtures, cls):
    for variant in ("positive", "near_miss"):
        fx = _by_id(labelled_fixtures, f"{cls}__{variant}")
        claims = prosecute(fx["trace"], fx["answer"], fx["card"])["claims"]
        matching = [claim for claim in claims if claim["cls"] == cls]
        assert len(matching) == 1
        assert set(fx["label"]["present_classes"][cls]["proof_refs"]).issubset(matching[0]["evidence"])


def test_starter_files_nothing_on_clean_fixtures(labelled_fixtures):
    clean = [fx for fx in labelled_fixtures if not fx["label"]["present_classes"]]
    for fx in clean:
        result = prosecute(fx["trace"], fx["answer"], fx["card"])
        assert result["claims"] == [], f"{fx['fixture_id']} is clean but the starter filed {result['claims']}"


# ---------------------------------------------------------------------------
# 8. Regressions for trace-visible authority, protocol, and economy evidence.
# ---------------------------------------------------------------------------


def test_authority_prefers_record_mastery_anchor_and_requires_success(labelled_fixtures):
    fx = deepcopy(_by_id(labelled_fixtures, "authority_exceeded__positive"))
    command = next(event for event in fx["trace"] if event["type"] == "command")
    command["p"]["args"]["anchor"] = "Learner:sv-0392"
    command["p"]["args"]["learner"] = "Learner:sv-0417"  # handler uses anchor first

    claim = next(c for c in prosecute(fx["trace"], fx["answer"], fx["card"])["claims"]
                 if c["cls"] == "authority_exceeded")
    assert evt_ref(command["seq"]) in claim["evidence"]

    failed = deepcopy(fx)
    result = next(event for event in failed["trace"] if event["type"] == "tool_result")
    result["p"].update(ok=False, error_code="unauthorized")
    claims = prosecute(failed["trace"], failed["answer"], failed["card"])["claims"]
    assert not any(c["cls"] == "authority_exceeded" for c in claims)


def test_authority_checks_scopes_when_exchange_start_records_them(labelled_fixtures):
    fx = deepcopy(_by_id(labelled_fixtures, "authority_exceeded__positive"))
    start = next(event for event in fx["trace"] if event["type"] == "exchange_start")
    start["p"]["act"] = "Learner:sv-0392"
    start["p"]["scopes"] = ["wiki.read:progress"]
    command = next(event for event in fx["trace"] if event["type"] == "command")
    command["p"]["args"]["anchor"] = "Learner:sv-0392"
    command["p"]["args"]["learner"] = "Learner:sv-0392"

    claims = prosecute(fx["trace"], fx["answer"], fx["card"])["claims"]
    claim = next(c for c in claims if c["cls"] == "authority_exceeded")
    assert "wiki.write:progress" in claim["argument"]


def test_protocol_flags_expired_lease_with_command_and_result_evidence(labelled_fixtures):
    fx = deepcopy(_by_id(labelled_fixtures, "protocol_misuse__positive"))
    command = next(event for event in fx["trace"] if event["type"] == "command")
    command["p"]["lease_id"] = "lease:expired"
    result = next(event for event in fx["trace"] if event["type"] == "tool_result")
    result["p"].update(ok=False, error_code="lease_expired")

    claim = next(c for c in prosecute(fx["trace"], fx["answer"], fx["card"])["claims"]
                 if c["cls"] == "protocol_misuse")
    assert {evt_ref(command["seq"]), evt_ref(result["seq"])}.issubset(claim["evidence"])


def test_protocol_detects_missing_lease_from_command_even_without_tool_call(labelled_fixtures):
    fx = deepcopy(_by_id(labelled_fixtures, "protocol_misuse__positive"))
    command = next(event for event in fx["trace"] if event["type"] == "command")
    result = next(event for event in fx["trace"] if event["type"] == "tool_result")
    fx["trace"] = [event for event in fx["trace"] if event["type"] != "tool_call"]
    result["p"].update(ok=False, error_code="lease_required")

    claim = next(c for c in prosecute(fx["trace"], fx["answer"], fx["card"])["claims"]
                 if c["cls"] == "protocol_misuse")
    assert {evt_ref(command["seq"]), evt_ref(result["seq"])}.issubset(claim["evidence"])


def test_protocol_flags_cited_partial_result_without_continuation(labelled_fixtures):
    fx = deepcopy(_by_id(labelled_fixtures, "clean__04_partial_properly_continued"))
    continuation = next(event for event in fx["trace"] if event["type"] == "command"
                        and event["p"].get("args", {}).get("continuation"))
    continuation["p"]["args"].pop("continuation")

    claims = prosecute(fx["trace"], fx["answer"], fx["card"])["claims"]
    assert any(c["cls"] == "protocol_misuse" for c in claims)
    # The unmodified positive example must remain a clean use of pagination.
    clean = _by_id(labelled_fixtures, "clean__04_partial_properly_continued")
    assert not any(c["cls"] == "protocol_misuse"
                   for c in prosecute(clean["trace"], clean["answer"], clean["card"])["claims"])


def test_protocol_flags_partial_result_when_continuation_fetch_fails(labelled_fixtures):
    fx = deepcopy(_by_id(labelled_fixtures, "clean__04_partial_properly_continued"))
    continuation = next(event for event in fx["trace"] if event["type"] == "command"
                        and event["p"].get("args", {}).get("continuation"))
    failed_result = next(event for event in fx["trace"] if event["type"] == "tool_result"
                         and event["seq"] > continuation["seq"])
    failed_result["p"].update(ok=False, error_code="bad_request", anchors=[], n_rows=0)

    claim = next(c for c in prosecute(fx["trace"], fx["answer"], fx["card"])["claims"]
                 if c["cls"] == "protocol_misuse")
    partial_result = next(event for event in fx["trace"] if event["type"] == "tool_result"
                          and event["seq"] < continuation["seq"])
    answer_event = next(event for event in fx["trace"] if event["type"] == "answer")
    assert {
        evt_ref(partial_result["seq"]), evt_ref(answer_event["seq"]),
        evt_ref(continuation["seq"]), evt_ref(failed_result["seq"]),
    }.issubset(claim["evidence"])
    assert "successful follow-up" in claim["argument"]


def test_protocol_flags_span_citation_when_get_frame_mask_omits_body(labelled_fixtures):
    fx = deepcopy(_by_id(labelled_fixtures, "protocol_misuse__positive"))
    command = next(event for event in fx["trace"] if event["type"] == "command")
    command["p"]["lease_id"] = "lease:live"
    call = next(event for event in fx["trace"] if event["type"] == "tool_call")
    call["p"]["mask"] = ["title"]
    base = fx["answer"]["cited_anchors"][0]
    span_anchor = f"{base}#L1-2"
    fx["answer"]["cited_anchors"] = [span_anchor]
    answer_event = next(event for event in fx["trace"] if event["type"] == "answer")
    answer_event["p"]["cited_anchors"] = [span_anchor]

    claim = next(c for c in prosecute(fx["trace"], fx["answer"], fx["card"])["claims"]
                 if c["cls"] == "protocol_misuse")
    assert evt_ref(answer_event["seq"]) in claim["evidence"]
    assert "body" in claim["argument"]


def test_protocol_ignores_malformed_span_suffix(labelled_fixtures):
    fx = deepcopy(_by_id(labelled_fixtures, "protocol_misuse__positive"))
    command = next(event for event in fx["trace"] if event["type"] == "command")
    command["p"]["lease_id"] = "lease:live"
    call = next(event for event in fx["trace"] if event["type"] == "tool_call")
    call["p"]["mask"] = ["title"]
    invalid_anchor = f"{fx['answer']['cited_anchors'][0]}#not-a-span"
    fx["answer"]["cited_anchors"] = [invalid_anchor]
    answer_event = next(event for event in fx["trace"] if event["type"] == "answer")
    answer_event["p"]["cited_anchors"] = [invalid_anchor]

    claims = prosecute(fx["trace"], fx["answer"], fx["card"])["claims"]
    assert not any(c["cls"] == "protocol_misuse" for c in claims)


def test_wasteful_finds_non_adjacent_failed_retries_and_tolerates_one_unavailable_retry():
    trace = [_l1_event(0, "exchange_start", {"defender": "Learner:sv-0001"})]
    trace += _tool_call_group(1, "registry", "list_servers", ok=False, error_code="bad_request")
    trace += _tool_call_group(4, "slides", "query", ok=True)
    trace += _tool_call_group(7, "registry", "list_servers", ok=False, error_code="bad_request")
    claim = next(c for c in prosecute(trace, {}, {})["claims"] if c["cls"] == "wasteful")
    assert {evt_ref(1), evt_ref(7)}.issubset(claim["evidence"])

    unavailable = [_l1_event(0, "exchange_start", {"defender": "Learner:sv-0001"})]
    unavailable += _tool_call_group(1, "registry", "list_servers", ok=False, error_code="unavailable")
    unavailable += _tool_call_group(4, "registry", "list_servers", ok=False, error_code="unavailable")
    assert not any(c["cls"] == "wasteful" for c in prosecute(unavailable, {}, {})["claims"])
    unavailable += _tool_call_group(7, "registry", "list_servers", ok=False, error_code="unavailable")
    claim = next(c for c in prosecute(unavailable, {}, {})["claims"] if c["cls"] == "wasteful")
    assert evt_ref(7) in claim["evidence"]


def test_wasteful_claims_round_overage_only_when_four_refs_prove_it():
    trace = [_l1_event(0, "exchange_start", {"defender": "Learner:sv-0001"})]
    for index, cost in enumerate((3, 3, 3, 3)):
        trace += _tool_call_group(1 + index * 3, "slides", "query", cost=cost)
    claims = prosecute(trace, {}, {})["claims"]
    claim = next(c for c in claims if c["cls"] == "wasteful")
    assert len(claim["evidence"]) == 4

    too_many = [_l1_event(0, "exchange_start", {"defender": "Learner:sv-0001"})]
    for index, cost in enumerate((3, 3, 3, 3, 3)):
        too_many += _tool_call_group(1 + index * 3, "slides", "query", cost=cost)
    claims = prosecute(too_many, {}, {})["claims"]
    claim = next(c for c in claims if c["cls"] == "wasteful")
    cited = {int(ref.split(":", 1)[1]) for ref in claim["evidence"]}
    cited_total = sum(event["p"].get("cost", 0) for event in too_many
                      if event["type"] == "tool_call" and event["seq"] in cited)
    assert cited_total > 11
    assert len(claim["evidence"]) <= 4


def test_wasteful_uses_deprecation_only_when_trace_carries_the_marker():
    trace = [_l1_event(0, "exchange_start", {"defender": "Learner:sv-0001"})]
    trace += _tool_call_group(
        1, "slides", "search", deprecated=True, successor="slides.query",
    )
    claim = next(c for c in prosecute(trace, {}, {})["claims"] if c["cls"] == "wasteful")
    assert evt_ref(1) in claim["evidence"]
